package stanford.capstone.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import stanford.capstone.DTO.DepartmentDTO;
import stanford.capstone.DTO.EmployeeDTO;
import stanford.capstone.model.Department;
import stanford.capstone.model.Employee;
import stanford.capstone.model.Position;
import stanford.capstone.service.DepartmentService;
import stanford.capstone.service.EmployeeService;
import stanford.capstone.service.PositionService;

import java.util.List;

@Controller
@RequestMapping("/manage")
public class ManagementController {
    @Autowired
    DepartmentService departmentService;
    @Autowired
    EmployeeService employeeService;
    @Autowired
    PositionService positionService;
    @GetMapping("")
    public String showLoginForm(Model model){
        return "manage";
    }

    @GetMapping("/departments")
    public String showDepartments(Model model){
        List<Department> departments= departmentService.findAllDepartments();
        model.addAttribute("departments", departments);
        return "manage-departments";
    }
    @GetMapping("/departments/{departmentId}")
    public String showDepartmentDetails(@PathVariable Long departmentId, Model model){
        Department department = departmentService.findDepartmentById(departmentId);
        model.addAttribute("department", department);
        List<Employee> employees = employeeService.findAllByDepartment(departmentId);
        model.addAttribute("employees", employees);
        return "department-details";

    }

    @GetMapping("/departments/add")
    public String showAddDepartmentForm(Model model) {
        model.addAttribute("department", new Department());
        return "add-department";
    }
    @PostMapping("/departments")
    public String addDepartment(@ModelAttribute DepartmentDTO departmentDTO) {
        departmentService.saveDepartment(departmentDTO);
        return "redirect:/manage/departments"; // Redirect to the department list page after adding the department
    }

    @GetMapping("/add-employee")
    public String showAddEmployeeForm(Model model) {
        List<Department> departments = departmentService.findAllDepartments();
        List<Position> positions = positionService.getAllPositions();
        model.addAttribute("departments", departments);
        model.addAttribute("positions", positions);
        EmployeeDTO employeeDTO = new EmployeeDTO();
        model.addAttribute("employee", employeeDTO); // Assuming you're binding form data to an Employee object
        return "add-employee";
    }
    @PostMapping("/employee")
    private String createEmployee(@ModelAttribute("employeeDTO") EmployeeDTO employeeDTO){
        employeeService.create(employeeDTO);
        return "redirect:/manage/departments";
    }

    @GetMapping("/updateEmployee/{employeeId}")
    public String showEditEmployeeForm(@PathVariable Long employeeId, Model model){
        Employee employee = employeeService.findEmployeeById(employeeId);

        model.addAttribute("employee", employee);
        return "edit-employee";
    }
}
