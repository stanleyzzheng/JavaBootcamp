package stanford.capstone.service;

import stanford.capstone.model.Position;

import java.util.List;

public interface PositionService {
//    public void savePosition(Position position);
//    public Position findPositionByName(String name);
    public Position findPositionById(Long id);

    List<Position> getAllPositions();
//    public List<Position> getAllPositions();
}
